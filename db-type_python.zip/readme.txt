This app shows you, which Type of Database in the website. It shows after the ports which use the databases:

db_ports = {
    "MySQL/MariaDB": 3306,
    "PostgreSQL": 5432,
    "SQL Server": 1433,
    "Oracle DB": 1521,
}

Music by SubspaceAudio
